## Dataset

The dataset is composed by 1840 essays distributed among 95 topics. We crawled the essays from the Essays database of the UOL Educação web portal (https://educacao.uol.com.br/bancoderedacoes).   The dataset tarball contains 95 directories, each one is named after its respective topic. Each directory contains two subdirectories and two files. The two subdirectories contain the essays, one subdirectory has the XML version of essays and another directory has the HTML version of the essay. The two files are the HTML and XML of the prompt about the released topic. There is another README in the tarball file that details the XML structure of the essays and the prompts.

## Essay XML

Each essay is named after its title, and the root tag of the XML of essays is <essay>.  Nested in the root tag we have the following tags:
     * <skills>: The aspects of the essay. Each aspect is nested in a <skill> tag.
              ** <skill>: It encompasses two other tags, <desc> which describes the aspect considered, and <grade> which contains the value of the grade itself.
     * <finalgrade>: Its is the sum of all aspects grades.
     * <title>: It is the title of the essay. As the title is not mandatory, sometimes there is a dummy value in this field.
     * <body>: It is the body of the essay itself. Many times, there are tags nested inside the body. The tags are <wrong>, when the human evaluator marked as wrong some text sement; and <correct>, which is the suggestion to correct the text segment written by the student.
     * <generalcomment>: It is a general comment that the human evaluator writes about the essay.
     * <specificaspects>: This is a comment that the evaluator details issues of the essay.

The grades for each aspects are between 0.0 and 2.0, and the final grade lies between 0.0 and 10.00. 

## Prompt

The root tag of the prompt is <prompt>, and inside it there are two nested tags, <title> and <body>. The first it is the title of the prompt and the second is the prompt itself.
